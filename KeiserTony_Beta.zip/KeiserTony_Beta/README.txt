Tony Keiser
MGD Term 1608
GitHub: https://github.com/keisto/Game-Design
Build Target: (Portrait) iPhone iOS 9.x +
Tested on: iPhone 6s Version: iOS 9.3.2

Device Sizing - Game still functions on iPad size screen, but scaling “x2” not added.
Animation - Zombie death animation not to correct scale for some reason.